print("""Trình bày các loại lỗi khi lập trình và cách bắt lỗi trong Python: 
SyntaxError:    Sai cú pháp	             'Thiếu dấu ) hoặc : '
RuntimeError:   Lỗi trong khi chạy	     'Chia cho 0, biến chưa khai báo'
Logical Error:  Lỗi logic, kết quả sai   'tinh sai công thức' """)