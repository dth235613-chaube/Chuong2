print("""Ý nghĩa các toán tử trong Python
1. / – Chia lấy kết quả thực
Trả về kết quả số thực (float).
2. // – Chia lấy phần nguyên
Tr về phần nguyên của phép chia (bỏ phần thập phân).
3. % – Chia lấy phần dư (modulo)
Trả về số dư của phép chia.
4. ** – Lũy thừa (power)
Tính số mũ (a mũ b).
5. and – Toán tử logic AND
Trả về True nếu cả hai vế đều đúng.
6. or – Toán tử logic OR
Trả về True nếu ít nhất một vế đúng.
7. is – So sánh định danh (identity)
Kiểm tra hai biến có trỏ đến cùng một đối tượng không (không chỉ là giá trị bằng nhau).""")