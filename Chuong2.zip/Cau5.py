print("""Các loại ghi chú trong Python

1. Ghi chú một dòng	#	Ghi chú ngắn, nhanh
2. Ghi chú nhiều dòng	'''...''' hoặc """   """ #ghi chú dài, nhiều dòng""")