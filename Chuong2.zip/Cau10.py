#Gốc	Viết ngắn gọn
x += 1
x /= 2
x -= 1
x += y
x -= (y + 7)
x *= 2
number_of_closed_cases += 2 * ncc