Toan=float(input("Nhap diem mon toan: "))
Ly=float(input("Nhap diem mon Ly: "))
Hoa=float(input("Nhap diem mon Hoa: "))
dtb=(Toan+Ly+Hoa)/3
print("Diem trung binh = ",dtb)
print("Diem lam tron: ",round(dtb,2))